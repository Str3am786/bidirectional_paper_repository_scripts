# Response to referees

## Response to Referee 1


## Response to Referee 2

## Summary of changes

1. Section 2.2. on variational principle rewritten with modified objective obeying zero variance property
2. Moved technical details of loss function proof to Appendix.
3. Add figure showing variance decay for learning frequency of SHO

## Other stuff

1. Guidelines for params as per QMC paper i.e. Should be long compared to (inverse) energy gap and particle should diffuse a long distance relative to length scales of problem.
2. Appendix on training details.